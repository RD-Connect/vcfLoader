

def prova(ciao):
    print ciao